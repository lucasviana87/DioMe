# Configurando-uma-inst-ncia-de-Banco-de-Dados-na-Azure
Repositório contendo resumos, anotações e dicas sobre o uso da Azure


Primeiro devemos entra no Porta Azure 
https://portal.azure.com/

Na menu Esquerd acessar SQL do Azure, caso não esteja na lista selecione "Todos os Serviços", em seguida pesquise SQL do Azure

Selecione + Criar

Depois :
- Instância Gerenciada de SQL do AZURE 
- Criar
- Colocar o nome na Instância
- Computação + armazenamento
