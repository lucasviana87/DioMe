# resumo-do-lab
Este repositório contém o resumo das lições aprendidas durante o desenvolvimento do lab na DIO
Criei meu primeiro repositório no Github
consegui um breve conhecimento sobre a platafarma do Azure


Vantagems de Ambiente em Nuvem

Alta disponibilidade
* A alta disponibilidade se concentra em garantir a disponibilidade máxima, independentemente de interrupções ou eventos que possam ocorrer.
* O Azure é um ambiente de nuvem altamente disponível com garantias de tempo de atividade, dependendo do serviço. 
*Essas garantias fazem parte dos SLAs  (Contratos de Nível de Serviço)

Escalabilidade
* A escalabilidade refere-se à capacidade de ajustar recursos para atender à demanda. 
* A capacidade de escalar significa que você poderá adicionar mais recursos para lidar melhor com o aumento da demanda.
* Se a demanda cair, você poderá reduzir seus recursos e, assim, reduzir seus custos.

Elasticidade
* Com a elasticidade, se você experimentasse um salto repentino acentuado na demanda, seus recursos implantados poderiam ser expandidos (automaticamente ou manualmente).

Confiabilidade
* Devido ao design descentralizado, a nuvem naturalmente dá suporte a uma infraestrutura confiável e resiliente. 
* Com um design descentralizado, a nuvem permite que você tenha recursos implantados em várias regiões do mundo.

Previsibilidade
* A previsibilidade na nuvem permite que você avance com confiança, seja no desempenho ou no custo. Ambas são influenciadas pelo Microsoft Azure Well-Architected Framework. 

Segurança
* A nuvem oferece ferramentas de segurança que atendem às necessidades dos clientes mas, é importante lembrar que a implementação de muitas delas devem ser realizadas pelo cliente. 

Governança
* A auditoria baseada em nuvem ajuda a sinalizar qualquer recurso que esteja fora de conformidade com seus padrões corporativos e fornece estratégias de mitigação. 

Gerenciabilidade
* O gerenciamento da nuvem diz respeito a gerenciar seus recursos de nuvem como:  Escalar automaticamente a implantação de recursos com base na necessidade.
* Implantar recursos com base em um modelo pré-configurado, removendo a necessidade de configuração manual.
* O gerenciamento na nuvem diz respeito à maneira de gerenciar seu ambiente de nuvem e seus recursos. Pelo portal Web e uma interface usando linha de comandos
